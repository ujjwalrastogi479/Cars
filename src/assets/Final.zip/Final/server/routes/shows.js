const express = require("express")
const router = express.Router()
const showController = require("../controllers/showController")
const { authenticate, isAdmin } = require("../middleware/auth")

// Get all shows
router.get("/", showController.getAllShows)

// Get show by ID
router.get("/:id", showController.getShowById)

// Create a new show (admin only)
router.post("/", authenticate, isAdmin, showController.createShow)

// Update show (admin only)
router.put("/:id", authenticate, isAdmin, showController.updateShow)

// Delete show (admin only)
router.delete("/:id", authenticate, isAdmin, showController.deleteShow)

module.exports = router
