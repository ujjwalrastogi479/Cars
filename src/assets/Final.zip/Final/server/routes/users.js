const express = require("express")
const router = express.Router()
const userController = require("../controllers/userController")
const { authenticate, isAdmin } = require("../middleware/auth")

// Get all users (admin only)
router.get("/", authenticate, isAdmin, userController.getAllUsers)

// Get user by ID
router.get("/:id", authenticate, userController.getUserById)

// Update user profile
router.put("/profile", authenticate, userController.updateProfile)

// Create admin account (admin only) 
router.post("/admin", userController.createAdmin)
// router.post("/admin", authenticate, isAdmin, userController.createAdmin)

// Delete user (admin only)
router.delete("/:id", authenticate, isAdmin, userController.deleteUser)

module.exports = router
