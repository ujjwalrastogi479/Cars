const express = require("express")
const router = express.Router()
const bookingController = require("../controllers/bookingController")
const { authenticate, isAdmin } = require("../middleware/auth")

// Get all bookings for a user
router.get("/my-bookings", authenticate, bookingController.getUserBookings)

// Get booking by ID
router.get("/:id", authenticate, bookingController.getBookingById)

// Create a new booking
router.post("/", authenticate, bookingController.createBooking)

// Cancel booking (admin only)
router.delete("/:id", authenticate, isAdmin, bookingController.cancelBooking)

// Get all bookings (admin only)
router.get("/", authenticate, isAdmin, bookingController.getAllBookings)

module.exports = router

