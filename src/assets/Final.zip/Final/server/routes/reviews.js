const express = require("express")
const router = express.Router()
const reviewController = require("../controllers/reviewController")
const { authenticate, isAdmin } = require("../middleware/auth")

// Get all reviews for a movie
router.get("/movie/:movieId", reviewController.getMovieReviews)

// Create a new review
router.post("/", authenticate, reviewController.createReview)

// Update review
router.put("/:id", authenticate, reviewController.updateReview)

// Delete review
router.delete("/:id", authenticate, reviewController.deleteReview)

// Delete review (admin)
router.delete("/admin/:id", authenticate, isAdmin, reviewController.adminDeleteReview)

module.exports = router
