const express = require("express")
const router = express.Router()
const movieController = require("../controllers/movieController")
const { authenticate, isAdmin } = require("../middleware/auth")

// Get all movies
router.get("/", movieController.getAllMovies)

// Get movie by ID
router.get("/:id", movieController.getMovieById)

// Create a new movie (admin only)
router.post("/", authenticate, isAdmin, movieController.createMovie)

// Update movie (admin only)
router.put("/:id", authenticate, isAdmin, movieController.updateMovie)

// Delete movie (admin only)
router.delete("/:id", authenticate, isAdmin, movieController.deleteMovie)

// Toggle movie active status (admin only)
router.patch("/:id/toggle", authenticate, isAdmin, movieController.toggleMovieStatus)

module.exports = router
