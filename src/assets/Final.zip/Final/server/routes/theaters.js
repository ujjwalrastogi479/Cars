const express = require("express")
const router = express.Router()
const theaterController = require("../controllers/theaterController")
const { authenticate, isAdmin } = require("../middleware/auth")

// Get all theaters
router.get("/", theaterController.getAllTheaters)

// Get theater by ID
router.get("/:id", theaterController.getTheaterById)

// Create a new theater (admin only)
router.post("/", authenticate, isAdmin, theaterController.createTheater)

// Update theater (admin only)
router.put("/:id", authenticate, isAdmin, theaterController.updateTheater)

// Delete theater (admin only)
router.delete("/:id", authenticate, isAdmin, theaterController.deleteTheater)

module.exports = router
