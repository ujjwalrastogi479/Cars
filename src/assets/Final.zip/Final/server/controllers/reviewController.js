const Review = require("../models/Review")
const Movie = require("../models/Movie")

// Get all reviews for a movie
exports.getMovieReviews = async (req, res) => {
  try {
    const { movieId } = req.params

    const reviews = await Review.find({ movieId }).populate("userId", "name profilePic").sort({ createdAt: -1 })

    res.json({ reviews })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Create a new review
exports.createReview = async (req, res) => {
  try {
    const { movieId, rating, comment } = req.body

    // Check if movie exists
    const movie = await Movie.findById(movieId)
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" })
    }

    // Check if user has already reviewed this movie
    const existingReview = await Review.findOne({
      userId: req.user._id,
      movieId,
    })

    if (existingReview) {
      return res.status(400).json({ message: "You have already reviewed this movie" })
    }

    // Create review
    const review = new Review({
      userId: req.user._id,
      movieId,
      rating,
      comment,
    })

    await review.save()

    // Update movie rating
    const allReviews = await Review.find({ movieId })
    const totalRating = allReviews.reduce((sum, review) => sum + review.rating, 0)
    const averageRating = totalRating / allReviews.length

    movie.rating = averageRating
    await movie.save()

    res.status(201).json({ message: "Review added successfully", review })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Update review
exports.updateReview = async (req, res) => {
  try {
    const { rating, comment } = req.body

    // Find the review
    const review = await Review.findOne({
      _id: req.params.id,
      userId: req.user._id,
    })

    if (!review) {
      return res.status(404).json({ message: "Review not found or not authorized" })
    }

    // Update review
    review.rating = rating
    review.comment = comment
    await review.save()

    // Update movie rating
    const movieId = review.movieId
    const allReviews = await Review.find({ movieId })
    const totalRating = allReviews.reduce((sum, review) => sum + review.rating, 0)
    const averageRating = totalRating / allReviews.length

    const movie = await Movie.findById(movieId)
    movie.rating = averageRating
    await movie.save()

    res.json({ message: "Review updated successfully", review })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Delete review
exports.deleteReview = async (req, res) => {
  try {
    // Find the review
    const review = await Review.findOne({
      _id: req.params.id,
      userId: req.user._id,
    })

    if (!review) {
      return res.status(404).json({ message: "Review not found or not authorized" })
    }

    const movieId = review.movieId

    // Delete review
    await Review.findByIdAndDelete(req.params.id)

    // Update movie rating
    const allReviews = await Review.find({ movieId })

    if (allReviews.length > 0) {
      const totalRating = allReviews.reduce((sum, review) => sum + review.rating, 0)
      const averageRating = totalRating / allReviews.length

      const movie = await Movie.findById(movieId)
      movie.rating = averageRating
      await movie.save()
    } else {
      // No reviews left, reset rating to 0
      const movie = await Movie.findById(movieId)
      movie.rating = 0
      await movie.save()
    }

    res.json({ message: "Review deleted successfully" })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Delete review (admin)
exports.adminDeleteReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id)
    if (!review) {
      return res.status(404).json({ message: "Review not found" })
    }

    const movieId = review.movieId

    // Delete review
    await Review.findByIdAndDelete(req.params.id)

    // Update movie rating
    const allReviews = await Review.find({ movieId })

    if (allReviews.length > 0) {
      const totalRating = allReviews.reduce((sum, review) => sum + review.rating, 0)
      const averageRating = totalRating / allReviews.length

      const movie = await Movie.findById(movieId)
      movie.rating = averageRating
      await movie.save()
    } else {
      // No reviews left, reset rating to 0
      const movie = await Movie.findById(movieId)
      movie.rating = 0
      await movie.save()
    }

    res.json({ message: "Review deleted successfully" })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}
