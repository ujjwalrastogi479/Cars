const Theater = require("../models/Theater")

// Get all theaters
exports.getAllTheaters = async (req, res) => {
  try {
    const theaters = await Theater.find()
    res.json({ theaters })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Get theater by ID
exports.getTheaterById = async (req, res) => {
  try {
    const theater = await Theater.findById(req.params.id)
    if (!theater) {
      return res.status(404).json({ message: "Theater not found" })
    }

    res.json({ theater })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Create a new theater (admin only)
exports.createTheater = async (req, res) => {
  try {
    const { name, location, address, facilities, screens } = req.body

    const theater = new Theater({
      name,
      location,
      address,
      facilities,
      screens,
    })

    await theater.save()

    res.status(201).json({ message: "Theater created successfully", theater })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Update theater (admin only)
exports.updateTheater = async (req, res) => {
  try {
    const { name, location, address, facilities, screens } = req.body

    const theater = await Theater.findByIdAndUpdate(
      req.params.id,
      {
        name,
        location,
        address,
        facilities,
        screens,
      },
      { new: true },
    )

    if (!theater) {
      return res.status(404).json({ message: "Theater not found" })
    }

    res.json({ message: "Theater updated successfully", theater })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Delete theater (admin only)
exports.deleteTheater = async (req, res) => {
  try {
    const theater = await Theater.findByIdAndDelete(req.params.id)
    if (!theater) {
      return res.status(404).json({ message: "Theater not found" })
    }

    res.json({ message: "Theater deleted successfully" })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}
