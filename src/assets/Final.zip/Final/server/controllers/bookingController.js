const Booking = require("../models/Booking")
const Show = require("../models/Show")

// Get all bookings for a user
exports.getUserBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ userId: req.user._id })
      .populate({
        path: "showId",
        populate: [
          { path: "movieId", select: "title poster" },
          { path: "theaterId", select: "name location" },
        ],
      })
      .sort({ bookingDate: -1 })

    res.json({ bookings })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Get booking by ID
exports.getBookingById = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate({
      path: "showId",
      populate: [{ path: "movieId" }, { path: "theaterId" }],
    })

    if (!booking) {
      return res.status(404).json({ message: "Booking not found" })
    }

    // Check if the booking belongs to the user or user is admin
    if (booking.userId.toString() !== req.user._id.toString() && req.user.role !== "admin") {
      return res.status(403).json({ message: "Access denied" })
    }

    res.json({ booking })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Create a new booking
exports.createBooking = async (req, res) => {
  try {
    const { showId, seats, totalAmount } = req.body

    // Verify show exists
    const show = await Show.findById(showId)
    if (!show) {
      return res.status(404).json({ message: "Show not found" })
    }

    // Check if seats are available
    const unavailableSeats = []

    for (const seat of seats) {
      const isBooked = show.bookedSeats.some((s) => s.row === seat.row && s.number === seat.number)

      if (isBooked) {
        unavailableSeats.push(`${seat.row}${seat.number}`)
      }
    }

    if (unavailableSeats.length > 0) {
      return res.status(400).json({
        message: "Some seats are already booked",
        unavailableSeats,
      })
    }

    // Create booking
    const booking = new Booking({
      userId: req.user._id,
      showId,
      seats,
      totalAmount,
      paymentStatus: "completed", // In a real app, this would be set after payment processing
    })

    await booking.save()

    // Update show's booked seats
    show.bookedSeats = [...show.bookedSeats, ...seats]
    await show.save()

    res.status(201).json({ message: "Booking created successfully", booking })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Cancel booking (admin only)
exports.cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
    if (!booking) {
      return res.status(404).json({ message: "Booking not found" })
    }

    // Update show's booked seats
    const show = await Show.findById(booking.showId)
    if (show) {
      // Remove the booked seats
      show.bookedSeats = show.bookedSeats.filter(
        (bookedSeat) => !booking.seats.some((seat) => seat.row === bookedSeat.row && seat.number === bookedSeat.number),
      )

      await show.save()
    }

    // Delete the booking
    await Booking.findByIdAndDelete(req.params.id)

    res.json({ message: "Booking cancelled successfully" })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Get all bookings (admin only)
exports.getAllBookings = async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate("userId", "name email")
      .populate({
        path: "showId",
        populate: [
          { path: "movieId", select: "title" },
          { path: "theaterId", select: "name location" },
        ],
      })
      .sort({ bookingDate: -1 })

    res.json({ bookings })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}
