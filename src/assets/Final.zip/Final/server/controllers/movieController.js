const Movie = require("../models/Movie")
const Review = require("../models/Review")

// Get all movies
exports.getAllMovies = async (req, res) => {
  try {
    const { genre, language, sort, search } = req.query

    // Build query
    const query = {}

    // Filter by genre
    if (genre) {
      query.genre = genre
    }

    // Filter by language
    if (language) {
      query.language = language
    }

    // Search by title or description
    if (search) {
      query.$text = { $search: search }
    }

    // Get movies
    let movies = Movie.find(query)

    // Sort
    if (sort) {
      const sortField = sort.startsWith("-") ? sort.substring(1) : sort
      const sortOrder = sort.startsWith("-") ? -1 : 1
      movies = movies.sort({ [sortField]: sortOrder })
    } else {
      movies = movies.sort({ releaseDate: -1 })
    }

    // Execute query
    const result = await movies.exec()

    res.json({ movies: result })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Get movie by ID
exports.getMovieById = async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id)
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" })
    }

    // Get reviews for the movie
    const reviews = await Review.find({ movieId: movie._id })
      .populate("userId", "name profilePic")
      .sort({ createdAt: -1 })

    res.json({ movie, reviews })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Create a new movie (admin only)
exports.createMovie = async (req, res) => {
  try {
    const { title, description, genre, language, duration, certificate, poster, banner, cast, releaseDate } = req.body

    const movie = new Movie({
      title,
      description,
      genre,
      language,
      duration,
      certificate,
      poster,
      banner,
      cast,
      releaseDate,
    })

    await movie.save()

    res.status(201).json({ message: "Movie created successfully", movie })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Update movie (admin only)
exports.updateMovie = async (req, res) => {
  try {
    const { title, description, genre, language, duration, certificate, poster, banner, cast, releaseDate, isActive } =
      req.body

    const movie = await Movie.findByIdAndUpdate(
      req.params.id,
      {
        title,
        description,
        genre,
        language,
        duration,
        certificate,
        poster,
        banner,
        cast,
        releaseDate,
        isActive,
      },
      { new: true },
    )

    if (!movie) {
      return res.status(404).json({ message: "Movie not found" })
    }

    res.json({ message: "Movie updated successfully", movie })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Delete movie (admin only)
exports.deleteMovie = async (req, res) => {
  try {
    const movie = await Movie.findByIdAndDelete(req.params.id)
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" })
    }

    // Also delete all reviews for this movie
    await Review.deleteMany({ movieId: req.params.id })

    res.json({ message: "Movie deleted successfully" })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Toggle movie active status (admin only)
exports.toggleMovieStatus = async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id)
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" })
    }

    movie.isActive = !movie.isActive
    await movie.save()

    res.json({
      message: `Movie ${movie.isActive ? "activated" : "deactivated"} successfully`,
      movie,
    })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}
