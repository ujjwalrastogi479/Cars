const Show = require("../models/Show")
const Movie = require("../models/Movie")
const Theater = require("../models/Theater")

// Get all shows
exports.getAllShows = async (req, res) => {
  try {
    const { movieId, theaterId, date } = req.query

    // Build query
    const query = {}

    // Filter by movie
    if (movieId) {
      query.movieId = movieId
    }

    // Filter by theater
    if (theaterId) {
      query.theaterId = theaterId
    }

    // Filter by date
    if (date) {
      const startDate = new Date(date)
      startDate.setHours(0, 0, 0, 0)

      const endDate = new Date(date)
      endDate.setHours(23, 59, 59, 999)

      query.showTime = { $gte: startDate, $lte: endDate }
    }

    // Get shows with populated movie and theater data
    const shows = await Show.find(query)
      .populate("movieId", "title poster duration certificate")
      .populate("theaterId", "name location")
      .sort({ showTime: 1 })

    res.json({ shows })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Get show by ID
exports.getShowById = async (req, res) => {
  try {
    const show = await Show.findById(req.params.id).populate("movieId").populate("theaterId")

    if (!show) {
      return res.status(404).json({ message: "Show not found" })
    }

    res.json({ show })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Create a new show (admin only)
exports.createShow = async (req, res) => {
  try {
    const { movieId, theaterId, screen, showTime, price } = req.body

    // Verify movie exists
    const movie = await Movie.findById(movieId)
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" })
    }

    // Verify theater exists
    const theater = await Theater.findById(theaterId)
    if (!theater) {
      return res.status(404).json({ message: "Theater not found" })
    }

    // Verify screen exists in theater
    const screenExists = theater.screens.some((s) => s.name === screen)
    if (!screenExists) {
      return res.status(400).json({ message: "Screen not found in this theater" })
    }

    // Find the screen to get its layout
    const theaterScreen = theater.screens.find((s) => s.name === screen)

    // Generate available seats based on screen layout
    const availableSeats = []
    const rows = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".slice(0, theaterScreen.seatsLayout.rows)

    for (let i = 0; i < rows.length; i++) {
      for (let j = 1; j <= theaterScreen.seatsLayout.columns; j++) {
        availableSeats.push({
          row: rows[i],
          number: j,
        })
      }
    }

    const show = new Show({
      movieId,
      theaterId,
      screen,
      showTime,
      price,
      availableSeats,
      bookedSeats: [],
    })

    await show.save()

    res.status(201).json({ message: "Show created successfully", show })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Update show (admin only)
exports.updateShow = async (req, res) => {
  try {
    const { showTime, price } = req.body

    const show = await Show.findByIdAndUpdate(req.params.id, { showTime, price }, { new: true })

    if (!show) {
      return res.status(404).json({ message: "Show not found" })
    }

    res.json({ message: "Show updated successfully", show })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Delete show (admin only)
exports.deleteShow = async (req, res) => {
  try {
    const show = await Show.findByIdAndDelete(req.params.id)
    if (!show) {
      return res.status(404).json({ message: "Show not found" })
    }

    res.json({ message: "Show deleted successfully" })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

