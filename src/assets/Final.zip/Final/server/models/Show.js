const mongoose = require("mongoose")

const showSchema = new mongoose.Schema(
  {
    movieId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Movie",
      required: true,
    },
    theaterId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Theater",
      required: true,
    },
    screen: {
      type: String,
      required: true,
    },
    showTime: {
      type: Date,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    availableSeats: [
      {
        row: String,
        number: Number,
      },
    ],
    bookedSeats: [
      {
        row: String,
        number: Number,
      },
    ],
  },
  { timestamps: true },
)

const Show = mongoose.model("Show", showSchema)

module.exports = Show
