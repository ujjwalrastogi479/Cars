const mongoose = require("mongoose")

const theaterSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    location: {
      type: String,
      required: true,
      trim: true,
    },
    address: {
      type: String,
      required: true,
    },
    facilities: [
      {
        type: String,
      },
    ],
    screens: [
      {
        name: String,
        capacity: Number,
        seatsLayout: {
          rows: Number,
          columns: Number,
        },
      },
    ],
  },
  { timestamps: true },
)

const Theater = mongoose.model("Theater", theaterSchema)

module.exports = Theater
